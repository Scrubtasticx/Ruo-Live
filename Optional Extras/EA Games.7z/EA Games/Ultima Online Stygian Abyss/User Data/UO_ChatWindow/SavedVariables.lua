ChatSettings.ChannelColors = 
{
	
	{
		r = 255,
		g = 255,
		b = 255,
	},
	
	{
		r = 215,
		g = 215,
		b = 1,
	},
	
	{
		r = 207,
		g = 56,
		b = 223,
	},
	
	{
		r = 75,
		g = 120,
		b = 230,
	},
	
	{
		r = 215,
		g = 215,
		b = 1,
	},
	
	{
		r = 215,
		g = 215,
		b = 1,
	},
	
	{
		r = 215,
		g = 215,
		b = 1,
	},
	
	{
		r = 215,
		g = 215,
		b = 1,
	},
	
	{
		r = 56,
		g = 191,
		b = 40,
	},
	
	{
		r = 96,
		g = 231,
		b = 0,
	},
	
	{
		r = 48,
		g = 215,
		b = 231,
	}, 
	[13] = 
	{
		r = 232,
		g = 48,
		b = 88,
	},
	[14] = 
	{
		r = 75,
		g = 120,
		b = 230,
	},
}



ChatWindow.Settings = 
{
	Version = 1.5,
	windowLocked = false,
	autohide = true,
	topWindow = "",
	Chat = 
	{
		Windows = 
		{
			
			{
				posY = 0.77843230962753,
				alpha = 1,
				windowMinAlpha = 0,
				windowName = "ChatWindow",
				sizeX = 488.21844482422,
				sizeY = 201.07284545898,
				movable = true,
				showTimestamp = false,
				windowMaxAlpha = 0.7,
				posX = -0.0005232862313278,
				numTabs = 1,
				rootName = "ChatWindow",
				Tabs = 
				{
					[1] = 
					{
						font = "UO_ChatText",
						name = "System",
						Filters = 
						{
							true,
							false,
							true,
							true,
							false,
							true,
							false,
							false,
							true,
							true,
							true, 
							[13] = true,
							[14] = true,
						},
					},
				},
				tabName = L"System",
			},
			
			{
				posY = 0.77843230962753,
				alpha = 1,
				windowMinAlpha = 0,
				windowName = "ChatWindow2",
				sizeX = 488.21844482422,
				sizeY = 201.07284545898,
				movable = true,
				showTimestamp = false,
				windowMaxAlpha = 0.7,
				posX = -0.0005232862313278,
				numTabs = 1,
				rootName = "ChatWindow",
				Tabs = 
				{
					[1] = 
					{
						font = "UO_ChatText",
						name = "Journal",
						Filters = 
						{
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true,
							true, 
							[13] = true,
							[14] = true,
						},
					},
				},
				tabName = L"Journal",
			},
		},
		numWindows = 2,
	},
}



